# -*- coding: utf-8 -*-

'''
    Tulip routine libraries, based on lambda's lamlib
    Author Twilight0

        License summary below, for more details please read license.txt file

        This program is free software: you can redistribute it and/or modify
        it under the terms of the GNU General Public License as published by
        the Free Software Foundation, either version 2 of the License, or
        (at your option) any later version.
        This program is distributed in the hope that it will be useful,
        but WITHOUT ANY WARRANTY; without even the implied warranty of
        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
        GNU General Public License for more details.
        You should have received a copy of the GNU General Public License
        along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import sys, os, xbmc, xbmcaddon, xbmcplugin, xbmcgui, xbmcvfs
from init import syshandle


integer = 1000
lang = xbmcaddon.Addon().getLocalizedString
setting = xbmcaddon.Addon().getSetting
setSetting = xbmcaddon.Addon().setSetting
addon = xbmcaddon.Addon
addonInfo = xbmcaddon.Addon().getAddonInfo

addItem = xbmcplugin.addDirectoryItem
addItems = xbmcplugin.addDirectoryItems
directory = xbmcplugin.endOfDirectory
content = xbmcplugin.setContent
property = xbmcplugin.setProperty
resolve = xbmcplugin.setResolvedUrl
sortmethod = xbmcplugin.addSortMethod

infoLabel = xbmc.getInfoLabel
condVisibility = xbmc.getCondVisibility
jsonrpc = xbmc.executeJSONRPC
keyboard = xbmc.Keyboard
sleep = xbmc.sleep
execute = xbmc.executebuiltin
skin = xbmc.getSkinDir()
player = xbmc.Player()
playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
monitor = xbmc.Monitor()
wait = monitor.waitForAbort

transPath = xbmc.translatePath
skinPath = xbmc.translatePath('special://skin/')
addonPath = xbmc.translatePath(addonInfo('path'))
dataPath = xbmc.translatePath(addonInfo('profile')).decode('utf-8')

window = xbmcgui.Window(10000)
dialog = xbmcgui.Dialog()
progressDialog = xbmcgui.DialogProgress()
windowDialog = xbmcgui.WindowDialog()
button = xbmcgui.ControlButton
image = xbmcgui.ControlImage
alphanum_input = xbmcgui.INPUT_ALPHANUM
password_input = xbmcgui.INPUT_PASSWORD
hide_input = xbmcgui.ALPHANUM_HIDE_INPUT
verify = xbmcgui.PASSWORD_VERIFY
item = xbmcgui.ListItem

openFile = xbmcvfs.File
makeFile = xbmcvfs.mkdir
deleteFile = xbmcvfs.delete
deleteDir = xbmcvfs.rmdir
listDir = xbmcvfs.listdir
exists = xbmcvfs.exists
copy = xbmcvfs.copy

join = os.path.join
settingsFile = os.path.join(dataPath, 'settings.xml')
bookmarksFile = os.path.join(dataPath, 'bookmarks.db')
cacheFile = os.path.join(dataPath, 'cache.db')


def infoDialog(message, heading=addonInfo('name'), icon='', time=3000):

    if icon == '':
        icon = addonInfo('icon')

    try:

        dialog.notification(heading, message, icon, time, sound=False)

    except:

        execute("Notification(%s, %s, %s, %s)" % (heading, message, time, icon))


def okDialog(heading, line1):
    return dialog.ok(heading, line1)


def inputDialog(heading):
    return dialog.input(heading)


def yesnoDialog(line1, line2='', line3='', heading=addonInfo('name'), nolabel=None, yeslabel=None):
    return dialog.yesno(heading, line1, line2, line3, nolabel, yeslabel)


def selectDialog(list, heading=addonInfo('name')):
    return dialog.select(heading, list)


def openSettings(query=None, id=addonInfo('id')):

    try:

        idle()
        execute('Addon.OpenSettings(%s)' % id)
        if query is None:
            raise Exception()
        c, f = query.split('.')
        execute('SetFocus(%i)' % (int(c) + 100))
        execute('SetFocus(%i)' % (int(f) + 200))

    except:

        return


# Alternative method
def Settings(id=addonInfo('id')):

    try:

        idle()
        xbmcaddon.Addon(id).openSettings()

    except:

        return


def openPlaylist():
    return execute('ActivateWindow(VideoPlaylist)')


def refresh():
    return execute('Container.Refresh')


def idle():
    return execute('Dialog.Close(busydialog)')


def set_view_mode(vmid):
    return execute('Container.SetViewMode({0})'.format(vmid))


# for compartmentalized theme addons
def addonmedia(icon, addonid=addonInfo('id'), theme=None):
    if not theme:
        return join(addon(addonid).getAddonInfo('path'), 'resources', 'media', icon)
    else:
        return join(addon(addonid).getAddonInfo('path'), 'resources', 'media', theme, icon)


def sortmethods(method, mask='%D'):

    """
    Function to sort directory items

    :param method: acceptable values are: TODO
    :param mask: acceptable values are: TODO
    :type method: str
    :type mask: str
    :return: call existing function and pass parameters
    :rtype: xbmcplugin.addSortMethod(handle=syshandle, sortMethod=int)
    :note: Method to sort directory items
    """

    #  "%A" "%B" "%C" "%D" ...

    if method == 'none':
        return sortmethod(handle=syshandle, sortMethod=0, label2Mask=mask)
    elif method == 'label':
        return sortmethod(handle=syshandle, sortMethod=1, label2Mask=mask)
    elif method == 'label_ignore_the':
        return sortmethod(handle=syshandle, sortMethod=2, label2Mask=mask)
    elif method == 'date':
        return sortmethod(handle=syshandle, sortMethod=3)
    elif method == 'size':
        return sortmethod(handle=syshandle, sortMethod=4)
    elif method == 'file':
        return sortmethod(handle=syshandle, sortMethod=5, label2Mask=mask)
    elif method == 'drive_type':
        return sortmethod(handle=syshandle, sortMethod=6)
    elif method == 'tracknum':
        return sortmethod(handle=syshandle, sortMethod=7, label2Mask=mask)
    elif method == 'duration':
        return sortmethod(handle=syshandle, sortMethod=8)
    elif method == 'title':
        return sortmethod(handle=syshandle, sortMethod=9, label2Mask=mask)
    elif method == 'title_ignore_the':
        return sortmethod(handle=syshandle, sortMethod=10, label2Mask=mask)
    elif method == 'artist':
        return sortmethod(handle=syshandle, sortMethod=11)
    elif method == 'artist_ignore_the':
        return sortmethod(handle=syshandle, sortMethod=12)
    elif method == 'album':
        return sortmethod(handle=syshandle, sortMethod=13)
    elif method == 'album_ignore_the':
        return sortmethod(handle=syshandle, sortMethod=14)
    elif method == 'genre':
        return sortmethod(handle=syshandle, sortMethod=15)
    elif method == 'year':
        return sortmethod(handle=syshandle, sortMethod=16)
    elif method == 'video_rating':
        return sortmethod(handle=syshandle, sortMethod=17)
    elif method == 'program_count':
        return sortmethod(handle=syshandle, sortMethod=18)
    elif method == 'playlist_order':
        return sortmethod(handle=syshandle, sortMethod=19)
    elif method == 'episode':
        return sortmethod(handle=syshandle, sortMethod=20)
    elif method == 'video_title':
        return sortmethod(handle=syshandle, sortMethod=21, label2Mask=mask)
    elif method == 'video_sort_title':
        return sortmethod(handle=syshandle, sortMethod=22, label2Mask=mask)
    elif method == 'video_sort_title_ignore_the':
        return sortmethod(handle=syshandle, sortMethod=23, label2Mask=mask)
    elif method == 'production_code':
        return sortmethod(handle=syshandle, sortMethod=24)
    elif method == 'song_rating':
        return sortmethod(handle=syshandle, sortMethod=25)
    elif method == 'mpaa_rating':
        return sortmethod(handle=syshandle, sortMethod=26)
    elif method == 'video_runtime':
        return sortmethod(handle=syshandle, sortMethod=27)
    elif method == 'studio':
        return sortmethod(handle=syshandle, sortMethod=28)
    elif method == 'studio_ignore_the':
        return sortmethod(handle=syshandle, sortMethod=29)
    elif method == 'unsorted':
        return sortmethod(handle=syshandle, sortMethod=30, label2Mask=mask)
    elif method == 'bitrate':
        return sortmethod(handle=syshandle, sortMethod=31)
    elif method == 'listeners':
        return sortmethod(handle=syshandle, sortMethod=32)
    elif method == 'country':
        return sortmethod(handle=syshandle, sortMethod=33)
    elif method == 'date_added':
        return sortmethod(handle=syshandle, sortMethod=34)
    elif method == 'full_path':
        return sortmethod(handle=syshandle, sortMethod=35, label2Mask=mask)
    elif method == 'label_ignore_folders':
        return sortmethod(handle=syshandle, sortMethod=36, label2Mask=mask)
    elif method == 'last_played':
        return sortmethod(handle=syshandle, sortMethod=37)
    elif method == 'play_count':
        return sortmethod(handle=syshandle, sortMethod=38)
    elif method == 'channel':
        return sortmethod(handle=syshandle, sortMethod=39, label2Mask=mask)
    elif method == 'date_taken':
        return sortmethod(handle=syshandle, sortMethod=40)
    elif method == 'video_user_rating':
        return sortmethod(handle=syshandle, sortMethod=41)
    elif method == 'song_user_rating':
        return sortmethod(handle=syshandle, sortMethod=42)
    else:
        pass
