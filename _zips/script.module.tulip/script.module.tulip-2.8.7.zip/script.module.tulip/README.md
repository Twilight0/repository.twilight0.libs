## Tulip Library (script.module.tulip)

Documentation can be found in each function's doc string (TODO)

Compatible with Kodi 16+
