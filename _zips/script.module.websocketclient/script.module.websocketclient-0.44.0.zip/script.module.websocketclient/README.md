websocket-client - 0.44.0
==============

websocket-client repacked for Kodi

Source: https://github.com/websocket-client/websocket-client

Version: [0.44.0](https://github.com/websocket-client/websocket-client/tree/8c90d16d0e9e59a524401d7324a8f7cbbae6888d)
