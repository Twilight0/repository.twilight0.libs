# script.module.shutil_which - 3.5.1

shutil_which repacked for Kodi

```py
try:
    from shutil import which
except ImportError:
    from shutil_which.shutil_which import which
```

Source: https://pypi.python.org/pypi/backports.shutil_which

Version: [3.5.1](https://github.com/minrk/backports.shutil_which)

## [repository.neverreply](https://github.com/neverreply/repo)
