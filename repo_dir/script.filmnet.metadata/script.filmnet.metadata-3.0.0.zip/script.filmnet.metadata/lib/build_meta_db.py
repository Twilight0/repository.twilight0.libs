#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_meta_db.py

Maintenance tool for the script.filmnet.metadata add-on.

Refreshes resources/data/meta.db by resolving every IMDb id in the `mv`
table against the TMDB /find endpoint. For each match it rewrites the
`poster` and `fanart` columns with the current TMDB image token and fills
in the `tmdb` movie id.

The Filmnet video add-on (plugin.video.filmnet/resources/lib/modules/
metacache.py) expands a token into a URL like this:

    https://image.tmdb.org/t/p/w300/<poster>.jpg
    https://image.tmdb.org/t/p/w1280/<fanart>.jpg

so only the bare file stem is stored (no leading '/', no extension).
'0' is the sentinel for "no artwork".

Safety
------
Existing artwork is never downgraded: if TMDB returns no poster/backdrop
for a title the previous value is kept. A row is considered *processed*
once `tmdb` is no longer NULL ('0' == processed, but TMDB had no match),
so a run can be interrupted and resumed.

A kept token can go stale on the CDN later on, so `--verify` switches the
tool into a liveness pass: every stored poster/fanart is HEAD-checked and
the tokens that no longer resolve are reset to '0'. Requests use IPv4 by
default (some image CDNs blackhole IPv6; use --no-ipv4 to allow it).

Examples
--------
    python3 build_meta_db.py                # update every unprocessed row
    python3 build_meta_db.py --limit 500    # quick smoke test
    python3 build_meta_db.py --all          # force a full refresh
    python3 build_meta_db.py --verify       # blank artwork that 404s
    python3 build_meta_db.py --verify --filter "rowid IN (...)"  # subset
    TMDB_API_KEY=xxxxxxxx python3 build_meta_db.py
"""

from __future__ import print_function

import argparse
import json
import os
import socket
import sqlite3
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor

try:
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError
except ImportError:  # pragma: no cover
    from urllib2 import Request, urlopen
    from urllib2 import HTTPError

# Same key that ships as the plugin.video.filmnet "tm.user" default.
# Override with --api-key or the TMDB_API_KEY environment variable.
DEFAULT_API_KEY = '9c61dcfae7065994ce1008535ece53eb'

FIND_URL = 'https://api.themoviedb.org/3/find/{imdb}?external_source=imdb_id&api_key={key}'
USER_AGENT = 'script.filmnet.metadata/3.0 (meta.db builder)'

# URL templates the consumer builds from a stored token
# (plugin.video.filmnet .../modules/metacache.py local()).
POSTER_URL = 'https://image.tmdb.org/t/p/w300/%s.jpg'
FANART_URL = 'https://image.tmdb.org/t/p/w1280/%s.jpg'

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..',
                       'resources', 'data', 'meta.db')


class RateLimiter(object):
    """Evenly spaces request starts so we stay under TMDB's ~50 req/s cap."""

    def __init__(self, rate_per_second):
        self._interval = 1.0 / float(rate_per_second)
        self._lock = threading.Lock()
        self._next = time.monotonic()

    def wait(self):
        with self._lock:
            now = time.monotonic()
            if now < self._next:
                time.sleep(self._next - now)
                now = self._next
            self._next = now + self._interval


def force_ipv4():
    """Resolve A records only. Some image CDNs blackhole IPv6 here, and urllib
    blocks on the dead IPv6 attempt until it times out."""
    original = socket.getaddrinfo

    def ipv4_only(*args, **kwargs):
        return [r for r in original(*args, **kwargs) if r[0] == socket.AF_INET]

    socket.getaddrinfo = ipv4_only


def image_token(path):
    """'/abc123.jpg' -> 'abc123'. Empty/invalid -> '0'."""
    if not path:
        return '0'
    name = os.path.basename(path)
    stem = os.path.splitext(name)[0]
    return stem or '0'


def fetch(imdb, api_key, limiter, retries=5):
    """Return the parsed /find JSON for an IMDb id, or None on failure."""
    url = FIND_URL.format(imdb=imdb, key=api_key)
    for attempt in range(retries):
        limiter.wait()
        try:
            req = Request(url, headers={'User-Agent': USER_AGENT})
            with urlopen(req, timeout=25) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except HTTPError as exc:
            if exc.code == 429:  # rate limited
                delay = exc.headers.get('Retry-After')
                time.sleep(float(delay) if delay else 5.0)
                continue
            if exc.code in (500, 502, 503, 504):  # transient
                time.sleep(2.0 * (attempt + 1))
                continue
            return None  # 404 / 401 / etc: give up on this title
        except Exception:
            time.sleep(1.0 * (attempt + 1))
    return None


def head_ok(url, limiter, retries=4):
    """True if the image exists. Conservative: keeps the token on transient errors."""
    for attempt in range(retries):
        limiter.wait()
        try:
            req = Request(url, method='HEAD', headers={'User-Agent': USER_AGENT})
            with urlopen(req, timeout=20) as resp:
                return True
        except HTTPError as exc:
            if exc.code in (404, 410):
                return False
            if exc.code == 429:
                delay = exc.headers.get('Retry-After')
                time.sleep(float(delay) if delay else 3.0)
                continue
            if exc.code >= 500:
                time.sleep(1.5 * (attempt + 1))
                continue
            return True
        except Exception:
            time.sleep(1.0 * (attempt + 1))
    return True


def resolve(rec, api_key, limiter):
    """Worker: map one (rowid, imdb, poster, fanart) to an update tuple."""
    rowid, imdb, poster, fanart = rec
    if not imdb or imdb == '0':
        return rowid, poster, fanart, '0', 'skip'

    data = fetch(imdb, api_key, limiter)
    if not data:
        return rowid, poster, fanart, '0', 'error'

    hit = None
    for key in ('movie_results', 'tv_results'):
        results = data.get(key) or []
        if results:
            hit = results[0]
            break

    if not hit:
        return rowid, poster, fanart, '0', 'nomatch'

    new_poster = image_token(hit.get('poster_path'))
    new_fanart = image_token(hit.get('backdrop_path'))
    return (
        rowid,
        new_poster if new_poster != '0' else poster,
        new_fanart if new_fanart != '0' else fanart,
        str(hit.get('id') or '0'),
        'ok',
    )


def human(seconds):
    seconds = int(max(0, seconds))
    return '%02d:%02d:%02d' % (seconds // 3600, (seconds % 3600) // 60, seconds % 60)


def verify_db(con, args):
    """HEAD-check every stored token and blank the ones that no longer resolve."""
    query = 'SELECT rowid, poster, fanart FROM mv'
    if args.filter:
        query += ' WHERE ' + args.filter
    if args.limit:
        query += ' LIMIT %d' % args.limit
    rows = con.execute(query).fetchall()
    total = len(rows)

    print('database : %s' % args.db)
    print('mode     : verify (%d rows)' % total)
    if not total:
        print('nothing to do.')
        return 0

    limiter = RateLimiter(args.rate)
    cur = con.cursor()
    started = time.monotonic()
    stats = {'p_checked': 0, 'p_dead': 0, 'f_checked': 0, 'f_dead': 0}

    def worker(rec):
        rowid, poster, fanart = rec
        check_p = bool(poster and poster != '0')
        check_f = bool(fanart and fanart != '0')
        ok_p = head_ok(POSTER_URL % poster, limiter) if check_p else True
        ok_f = head_ok(FANART_URL % fanart, limiter) if check_f else True
        return (rowid, poster if ok_p else '0', fanart if ok_f else '0',
                int(check_p), int(not ok_p), int(check_f), int(not ok_f))

    def flush(results):
        updates = []
        for rowid, new_poster, new_fanart, cp, dp, cf, df in results:
            stats['p_checked'] += cp
            stats['p_dead'] += dp
            stats['f_checked'] += cf
            stats['f_dead'] += df
            if dp or df:
                updates.append((new_poster, new_fanart, rowid))
        if updates:
            cur.executemany('UPDATE mv SET poster=?, fanart=? WHERE rowid=?', updates)
        con.commit()

    processed = 0
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        for start in range(0, total, args.chunk):
            chunk = rows[start:start + args.chunk]
            flush(pool.map(worker, chunk))
            processed += len(chunk)

            elapsed = time.monotonic() - started
            rate = processed / elapsed if elapsed else 0
            eta = (total - processed) / rate if rate else 0
            if processed == total or start % args.log_every < args.chunk:
                print('[%7d/%7d] %5.1f rows/s  eta %s  dead posters=%d fanart=%d' % (
                    processed, total, rate, human(eta),
                    stats['p_dead'], stats['f_dead']))
                sys.stdout.flush()

    con.execute('PRAGMA optimize')
    con.commit()

    elapsed = time.monotonic() - started
    print('done in %s (%d rows)' % (human(elapsed), total))
    print('  posters: %d checked, %d dead -> blanked' % (stats['p_checked'], stats['p_dead']))
    print('  fanart : %d checked, %d dead -> blanked' % (stats['f_checked'], stats['f_dead']))
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(description='Refresh meta.db artwork from TMDB.')
    parser.add_argument('--db', default=os.path.normpath(DB_PATH),
                        help='path to meta.db (default: add-on resources/data/meta.db)')
    parser.add_argument('--api-key',
                        default=os.environ.get('TMDB_API_KEY', DEFAULT_API_KEY),
                        help='TMDB v3 API key (default: $TMDB_API_KEY or built-in)')
    parser.add_argument('--workers', type=int, default=16,
                        help='concurrent requests (default: 16)')
    parser.add_argument('--rate', type=float, default=None,
                        help='max request starts per second (default: 35 scrape, 120 verify)')
    parser.add_argument('--limit', type=int, default=0,
                        help='process at most N rows (0 = all)')
    parser.add_argument('--all', action='store_true',
                        help='re-refresh rows that already have a tmdb id')
    parser.add_argument('--verify', action='store_true',
                        help='do not scrape; HEAD-check poster/fanart and blank dead tokens')
    parser.add_argument('--filter', default='',
                        help='extra SQL WHERE clause to restrict the rows handled')
    parser.add_argument('--ipv4', dest='ipv4', action='store_true', default=True,
                        help='force IPv4 for requests (default; use --no-ipv4 to allow IPv6)')
    parser.add_argument('--no-ipv4', dest='ipv4', action='store_false',
                        help='do not force IPv4')
    parser.add_argument('--chunk', type=int, default=1000,
                        help='rows per commit (default: 1000)')
    parser.add_argument('--log-every', type=int, default=500,
                        help='progress line every N rows (default: 500)')
    args = parser.parse_args(argv)

    if not args.verify and not args.api_key:
        parser.error('no TMDB API key (use --api-key or $TMDB_API_KEY)')
    if not os.path.exists(args.db):
        parser.error('database not found: %s' % args.db)
    if args.rate is None:
        args.rate = 120.0 if args.verify else 35.0
    if args.ipv4:
        force_ipv4()

    con = sqlite3.connect(args.db)
    con.execute('PRAGMA synchronous=NORMAL')

    if args.verify:
        try:
            return verify_db(con, args)
        finally:
            con.close()

    query = 'SELECT rowid, imdb, poster, fanart FROM mv'
    if not args.all:
        query += ' WHERE tmdb IS NULL'
    if args.limit:
        query += ' LIMIT %d' % args.limit
    rows = con.execute(query).fetchall()

    total = len(rows)
    print('database : %s' % args.db)
    print('rows     : %d to process (%s)' % (
        total, 'all' if args.all else 'tmdb IS NULL'))
    if not total:
        print('nothing to do.')
        con.close()
        return 0

    limiter = RateLimiter(args.rate)
    cur = con.cursor()
    started = time.monotonic()
    stats = {'ok': 0, 'nomatch': 0, 'error': 0, 'skip': 0}

    def flush(chunk_results):
        updates = []
        for rowid, poster, fanart, tmdb, kind in chunk_results:
            stats[kind] = stats.get(kind, 0) + 1
            updates.append((poster, fanart, tmdb, rowid))
        cur.executemany('UPDATE mv SET poster=?, fanart=?, tmdb=? WHERE rowid=?', updates)
        con.commit()

    processed = 0
    worker = lambda rec: resolve(rec, args.api_key, limiter)
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        for start in range(0, total, args.chunk):
            chunk = rows[start:start + args.chunk]
            flush(pool.map(worker, chunk))  # map submits only this chunk's futures
            processed += len(chunk)

            elapsed = time.monotonic() - started
            rate = processed / elapsed if elapsed else 0
            eta = (total - processed) / rate if rate else 0
            if processed == total or start % args.log_every < args.chunk:
                print('[%7d/%7d] %5.1f req/s  eta %s  ok=%d nomatch=%d err=%d' % (
                    processed, total, rate, human(eta),
                    stats['ok'], stats['nomatch'], stats['error']))
                sys.stdout.flush()

    con.execute('PRAGMA optimize')
    con.commit()
    con.close()

    elapsed = time.monotonic() - started
    print('done in %s (%d rows)' % (human(elapsed), total))
    print('  matched : %d' % stats['ok'])
    print('  no match: %d' % stats['nomatch'])
    print('  errors  : %d' % stats['error'])
    print('  skipped : %d' % stats['skip'])
    return 0


if __name__ == '__main__':
    sys.exit(main())
