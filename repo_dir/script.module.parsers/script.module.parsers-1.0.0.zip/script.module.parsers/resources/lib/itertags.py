# -*- coding: utf-8 -*-

'''
    Tulip library
    Author Twilight0

    SPDX-License-Identifier: GPL-3.0-only
    See LICENSES/GPL-3.0-only for more information.
'''

import re
from collections import namedtuple


def itertags(html, tag):
    """
    Brute force regex based HTML tag parser. This is a rough-and-ready searcher to find HTML tags when
    standards compliance is not required. Will find tags that are commented out, or inside script tag etc.
    Shamelessly taken from streamlink library: https://github.com/streamlink/streamlink

    :param html: HTML page
    :param tag: tag name to find
    :return: generator with Tags
    """

    tag_re = re.compile(
        r'''(?=<(?P<tag>[\w:-]+)(?P<attr>.*?)(?P<end>/)?>(?:(?P<inner>.*?)</\s*(?P=tag)\s*>)?)''',
        re.MULTILINE | re.DOTALL
    )
    attr_re = re.compile(
        r'''\s*(?P<key>[\w-]+)\s*(?:=\s*(?P<quote>["']?)(?P<value>.*?)(?P=quote)\s*)?'''
    )
    Match = namedtuple("Match", "tag attributes text")

    for match in tag_re.finditer(html):

        if match.group("tag") == tag or re.fullmatch(tag, match.group("tag")):
            attrs = dict((a.group("key").lower(), a.group("value")) for a in attr_re.finditer(match.group("attr")))

            yield Match(match.group("tag"), attrs, match.group("inner"))


def wrapper(html, tag, attrs=None, ret=False):
    try:

        result = list(itertags(html, tag))

        if isinstance(attrs, dict):
            attrs = list(iter(attrs.items()))

            result = [
                i for i in result if any(
                    [
                        a for a in attrs if any(
                        [
                            (a[0] == k or re.fullmatch(a[0], k)) and re.match(a[1], v) for k, v in
                            iter(i.attributes.items())
                        ]
                    )
                    ]
                )
            ]

        if ret:
            # noinspection PyTypeChecker
            result = [i.attributes[ret] for i in result if ret in i.attributes]

    except Exception:

        result = []

    return result


def parse_headers(string):
    """
    Converts a multi-line response/request headers string into a dictionary
    :param string: string of headers
    :return: dictionary of response headers
    """

    headers = dict([line.partition(': ')[::2] for line in string.splitlines()])

    return headers


__all__ = ['itertags', 'wrapper', 'parse_headers']
